<?php

namespace Ronanflavio\Easychat\Traits;

use Auth;

trait User
{
    //
}
